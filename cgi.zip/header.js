$(document).ready(function() {
    $('#nav-login').click(function () {
             
    window.location.href = "./login.php";
    });

    $('#nav-signup').click(function () {
             
        window.location.href = "./register.php";
    });
    $('#nav-company').click(function () {
             
        window.location.href = "./business.php";
    });
    $('#company-login').click(function () {
             
        window.location.href = "./business.php";
    });
});