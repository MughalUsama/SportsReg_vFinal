$(document).ready(function() {
    
    $('#nav-logout').click(function () {
        //write logout code here     
        window.location.href = "./";
        });


});