
$(document).ready(function() {
 
    $("#username").text($("#adminname").text());

});