<?php

define('DBUSER','root');
define('DBPWD','');
define('DBHOST','localhost');
define('DBNAME','sportsreg');

// define('DBUSER','wellyoed_usama');
// define('DBPWD','usama1133');
// define('DBHOST','localhost');
// define('DBNAME','wellyoed_sportsreg');


?>